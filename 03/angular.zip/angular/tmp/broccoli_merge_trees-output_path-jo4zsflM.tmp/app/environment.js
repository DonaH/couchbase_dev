"use strict";
exports.environment = {
    production: false
};
//# sourceMappingURL=environment.js.map