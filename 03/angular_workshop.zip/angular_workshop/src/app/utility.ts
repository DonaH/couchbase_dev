import {Injectable, Inject} from "@angular/core";

@Injectable()
export class Utility {

    // TODO: use the correct URL for the RESTful backend
    host: string = "http://localhost:62915";  // dotnet (port number may vary)
//    host: string = "http://localhost:8080"; // java
//    host: string = "http://localhost:3000"; // node

}